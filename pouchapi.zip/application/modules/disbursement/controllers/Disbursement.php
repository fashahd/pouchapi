<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
class Disbursement extends REST_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->helper('url');

		$this->load->view('welcome_message');
	}
	
	function create_post(){
		$this->load->model("ModelDisbursement");
		$headers=array();
		foreach (getallheaders() as $name => $value) {
			$headers[$name] = $value;
		}
		if(isset($headers["secret_key"])){
			if($headers["secret_key"] != ""){
				$secret_key  = $headers["secret_key"];
				$external_id = $this->input->post("external_id");
				$amount 	 = $this->input->post("amount");
				$bank_code 	 = $this->input->post("bank_code");
				$account_name 	= $this->input->post("account_holder_name");
				$account_number = $this->input->post("account_number");
				$description = $this->input->post("description");

				$data 		= array($external_id,$amount,$bank_code,$account_name,$account_number,$description,$secret_key);
				$response	= $this->ModelDisbursement->create($data);
			}else{
				$response 	= array(
					"status" => "401",
					"message" => "Failed on Authentication"
				);
			}
		}else{
			$response 	= array(
				"status" => "401",
				"message" => "Failed on Authentication"
			);
		}
		$this->response($response, REST_Controller::HTTP_OK);
	}
}